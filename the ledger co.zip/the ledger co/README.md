# The Ledger Co

# Author

- Vijay Prajapati

## Pre-Requisites

- `pip install -r requirements.txt`

## Run

`python3.8 ledger.py <YOUR ARGUMENT>`
